CHECKPOINTS = {
    'model_extenstion' : '.ckpt',
    'config_extenstion' : '.json'
}
