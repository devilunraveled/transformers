"""
This file is meant to be used for quick testing of the model.
You can pass the model id as a command line argument to run this file.

This is just done for inference and is not a model training script.
"""
