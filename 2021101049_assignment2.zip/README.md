# transformers
Implementation of Transformers module in python, using only Linear Layers as support from PyTorch. Implemented as part of Course Work for he couse Advanced Natural Language Processing @ IIIT H.

The github link is : https://github.com/devilunraveled/transformers
